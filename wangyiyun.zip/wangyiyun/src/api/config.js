const config = {
  // site: 'https://bird.ioliu.cn/v1?url=',
  // method: 'http://118.89.226.181:3000'
  site: '',
  method: ''
};
export const API_ROOT = ''.concat(config.site, config.method);
