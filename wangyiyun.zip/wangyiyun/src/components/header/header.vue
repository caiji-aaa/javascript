<template>
  <div class="header">
    <div class="name">

      <!-- <router-link to="./menu" class="item">
        <span class=""><i class="func-icon"></i></span>
      </router-link> -->

      <span @click="showAsideMenu(true)" class="func"><i class="func-icon"></i></span>
      <router-link to="/playLists/2821115454" class="item">
        <span class="music"><i class="music-icon"></i></span>
      </router-link>
      <router-link to="/playLists/2806848825" class="item">
        <span class="personal"><i class="personal-icon"></i></span>
      </router-link>
      <span class="search"><i @click="toSearch" class="search-icon"></i></span>

        
    </div>
  </div>
</template>

<script>
export default {
  name: 'header',
  methods: {
    toSearch () {
      this.$router.push('/search');
    },
    showAsideMenu (flag) {
      this.$store.commit('showAsideMenu', flag);
    }
  }
};
</script>
<style lang="stylus" rel="stylesheet/stylus" scoped>
  @import "header.styl";
</style>
